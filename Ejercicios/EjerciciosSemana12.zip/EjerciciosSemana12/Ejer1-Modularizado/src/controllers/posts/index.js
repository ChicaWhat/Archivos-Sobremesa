import getPostControllers from "./getPostControllers.js";
import newPostController from "./newPostController.js";

export {
    getPostControllers,
    newPostController
};